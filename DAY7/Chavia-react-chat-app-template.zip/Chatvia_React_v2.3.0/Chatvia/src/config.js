const config = {
    API_URL: "http://localhost:8000/",
    AUTH_BACKEND: 'Dummy'
}

export default config
